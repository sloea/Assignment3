import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Crawler2014302580087 {
	//����

	//��ȡ�б���ÿ����ʦ��ҳ��urlֵ
	public void teacher() throws IOException{
	Document doc = Jsoup.connect("http://www.cs.fudan.edu.cn/?page_id=348").get();
	Elements element=doc.select("div#xs-post");
	String contain=new String(element.toString());
	Document doc1=Jsoup.parse(contain);
	Elements link=doc1.select("a");
	int count =0;
	for (Iterator<Element> it = link.iterator(); it.hasNext();) {
		   Element e = (Element) it.next();
		   String teacherURL=e.attr("href");
		   //��ȡÿ��������ҳ�����ļ�
		   HttpRequest response=HttpRequest.get(teacherURL);
		   String filename=count+".html";
			if(response.ok()){
				response.receive(new File(filename));
				//System.out.println("ok");
			}
			count++;
		  }
	//System.out.print(count);
}
}


