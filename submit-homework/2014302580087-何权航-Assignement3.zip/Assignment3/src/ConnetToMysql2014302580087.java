import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;


public class ConnetToMysql2014302580087 {
	public void run() throws ClassNotFoundException, SQLException, IOException{
		 //����
		 String url = "jdbc:mysql://127.0.0.1:3306/test" ;    
	     String username = "root" ;   
	     String password = "123456" ;
	     String sql;
	     PreparedStatement ps;

	     //
         Class.forName("com.mysql.jdbc.Driver") ; //����MySql��������  
         Connection con =DriverManager.getConnection(url , username , password ) ;//�������ݿ������
         try {
        	 Analysis20143025800087 test=new Analysis20143025800087();
        	 test.run();
        	 for(int i=0; i<36;i++){
        	 sql="insert into teacher (name,phonenumber,email,summary,direction) values('"+test.name[i]+"','"+test.phonenumber[i]+"','"+test.email[i]+"','"+test.summary[i]+"','"+test.direction[i]+"')";
             ps = (PreparedStatement) con.prepareStatement(sql);
             ps.executeUpdate(sql);
             ps.close();
             }
             con.close();
         } catch (SQLException e) {
             e.printStackTrace();
         }


	}
}
