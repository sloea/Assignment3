import java.io.IOException;
import java.sql.SQLException;



public class Main2014302580087 {



	public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException, InterruptedException {
		// TODO �Զ����ɵķ������
		final Crawler2014302580087 a=new Crawler2014302580087();
		//a.teacher();
		final ConnetToMysql2014302580087 b =new ConnetToMysql2014302580087();
		//b.run();
		//���̷߳���
		Thread t =Thread.currentThread();
        t.setName("���߳�");
        long time1=System.currentTimeMillis();
        a.teacher();
		b.run();
		long time2=System.currentTimeMillis();
		System.out.print("���߳�ʱ�䣺");
		System.out.print(time2-time1);
		
		
		//���̷߳���
		class MyThread1 extends Thread {
			public void run() {
				try {
					a.teacher();
				} catch (IOException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
		}
		class MyThread2 extends Thread {
			public void run() {
				try {
					b.run();
				} catch (ClassNotFoundException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				} catch (IOException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
		}
		MyThread1 myThread1 = new MyThread1();
		MyThread2 myThread2 = new MyThread2();
		long time3=System.currentTimeMillis();
		myThread1.start();  
		myThread2.start();
		myThread1.join();
		myThread2.join();
		long time4=System.currentTimeMillis();
		System.out.print("\r\n"+"���߳�ʱ�䣺");
		System.out.print(time4-time3);

	    
	
	 
	
	}
}



