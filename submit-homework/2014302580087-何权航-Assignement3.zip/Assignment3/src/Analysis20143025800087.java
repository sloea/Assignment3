import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


public class Analysis20143025800087 {
	//����
    Document doc[] = new Document[100];
	String name[] = new String[100];
	String summary[]= new String[100];
	String direction[]= new String[100];
	String email[]= new String[100];
	String phonenumber[]= new String[100];
	
	public void run() throws IOException{


	    //����������ҳ
		for(int i=0;i<36;i++){
		    File input = new File(i+".html");
		    doc[i]= Jsoup.parse(input, "UTF-8", "");
		    //��ȡ����
		    Elements namehtml = doc[i].select("h1");
		    name[i]=namehtml.text();
		    //
		    Elements wordhtml = doc[i].select("p");
		    //��ȡ�绰����
		    Pattern pattern=Pattern.compile("[0-9]{2}-[0-9]{2}-[0-9]{8}");
			Matcher matcher=pattern.matcher(wordhtml.text());
			if(matcher.find()){
				phonenumber[i]=matcher.group();
			}
			else{
				phonenumber[i]="null";
			}
			//��ȡ����
			Pattern pattern1=Pattern.compile("[a-z0-9A-Z]+@([a-z0-9A-Z]+\\.)+[a-z0-9A-Z]{2,3}");
			Matcher matcher1=pattern1.matcher(wordhtml.text());
			if(matcher1.find()){
				email[i]=matcher1.group();
			}
			//��ȡ�о�����
			Elements ahtml = doc[i].select("p:contains(�о�����)");
			direction[i]=ahtml.text();
		    //��ȡ���
		    Elements bhtml = doc[i].select("p:contains(ѧλ)");
		    summary[i]=bhtml.text();
			//����
			//System.out.print(i+" "+summary[i]+"\r\n");
		}

	}
	
}
